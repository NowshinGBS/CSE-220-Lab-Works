import java.util.*;
public class AdjList{
Node head[];
int size;
AdjList(int s){
	size = s;
  head = new Node[s]; 
}


public void insertEdge(int edgeCount){
Scanner fr = new Scanner(System.in);

for (int q = 0; q < edgeCount; q++) {
	int i = fr.nextInt();
	int j = fr.nextInt();
	Node n = new Node(1, null);
	Node m = new Node(0, null);
if(head[i]==null){
head[i]=n;
}else{
	for(Node k = head[i];;k=k.next){
		if(k.next==null){
			k.next=n;
			break;
		}
	}
}

}
}



public void printList(){
  for(int i=0; i<head.length; i++){
    for(Node n =head[i]; n!=null; n=n.next){
    System.out.print(head[i].val+" ");
    }
    System.out.println();
  }
}
}
