import java.util.Scanner;
public class Tester{
  public static void main (String [] args){
    
    
    Scanner fr = new Scanner(System.in);
    System.out.println("size");
    int size = fr.nextInt();
    AdjList a = new AdjList(size);
    System.out.println("edge");
    int x = fr.nextInt();
//    int y = fr.nextInt();
    a.insertEdge(x);
    a.printList();
  }
}