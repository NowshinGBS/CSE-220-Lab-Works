public class QueueUnderflowException extends Exception {

}
