public class PatientInfoArray {
	Object id;
	String name;
	public PatientInfoArray(Object id, String name){
		this.id = id;
		this.name = name;
	}
}
