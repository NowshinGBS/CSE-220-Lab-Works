public class Node{
  public int data;
  public Node next;
  
  public Node(int a, Node n){
    data = a;
    next = n;
    
  } 
}