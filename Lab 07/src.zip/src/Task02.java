
public class Task02{
	  public static void main(String[]args){
	    String exp="1+2*(3/4)";
	    ArrayStack s=new ArrayStack();
	    ListStack p=new ListStack();
	    boolean flag=false;
	    int i=0;
	    char c='\u0000';
	    try{
	      while(i<=exp.length()-1){
	        c = exp.charAt(i);
	        if(c=='(' || c=='[' || c=='{'){
	          s.push(c);
	          p.push(i);
	        }else if(c==')' || c==']' || c=='}'){
	          char popCh=(char)s.pop();
	          int popInt=(int)p.pop();
	          if(popCh=='(' && c==')'){
	            flag=true;
	          }else if(popCh=='{' && c=='}'){
	            flag=true;
	          }else if(popCh=='[' && c==']'){
	            flag=true;
	          }else{
	            System.out.println("Error at character# "+popInt +".  '"+ popCh+"'- not closed!");
	            flag=false;
	            break;
	          }
	        }
	        i++;
	      }
	    }catch(Exception e){
	      flag=false;
	      System.out.println("Error at character# "+i+".  '"+ c+"'- not opened!");
	    }
	    if(s.isEmpty()){
	      if(flag){
	        System.out.println("Balanced!");
	      }else{
	        System.out.println("Not balanced!");
	      }
	    }
	    if(s.isEmpty()==false){
	      System.out.println("Not balanced!");
	    }
	  }
	}